import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import Groq from 'groq-sdk';

dotenv.config();

const app = express();

// Middleware with error handling
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
  next();
});

app.use(cors()); 
app.use(express.json({ limit: '10mb' })); // Add limit

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// Specialized MCQ analysis endpoint
app.post('/api/mcq-analysis', async (req, res) => {
    const startTime = Date.now();
    
    try {
        console.log("=== MCQ ANALYSIS STARTED ===");
        const { question, options, userAnswer } = req.body;
        
        // Validate MCQ format
        if (!question || !options || !Array.isArray(options)) {
            return res.status(400).json({ error: "Invalid MCQ format" });
        }

        // Create enhanced prompt for MCQ analysis
        const mcqPrompt = {
            role: 'system',
            content: `You are an expert Physics MCQ analyzer specializing in electromagnetic induction. 

**PHYSICS ACCURACY RULES:**
- Rotating coil in magnetic field produces sinusoidal current
- Current is maximum when coil is parallel to field
- Current is zero when coil is perpendicular to field
- Current continuously changes (varies sinusoidally)
- Flux Φ = BA cos(θ), EMF = -dΦ/dt

**ANALYSIS FORMAT:**
1. **Correct Answer**: [Letter]) [Answer Text] - MUST BE PHYSICALLY ACCURATE
2. **Difficulty Level**: Easy/Medium/Hard with reasoning
3. **Concept Tested**: Main physics principle
4. **Step-by-Step Explanation**: Physics reasoning process
5. **Distractor Analysis**: Why each wrong option is incorrect
6. **Visualization**: How to imagine the rotating coil
7. **Key Formula**: Relevant physics equation
8. **Study Tip**: Memory aid for similar questions

**VISUALIZATION ELEMENTS:**
- Describe coil rotation in magnetic field
- Mention key positions (0°, 90°, 180°, 270°)
- Explain sinusoidal current pattern
- Use descriptive language for mental imagery

**ACCURACY CHECK:**
- Verify answer against fundamental physics principles
- Ensure explanation matches mathematical relationships
- Check that distractors are properly analyzed

Keep response under 250 words but comprehensive.`
        };

        const userMessages = [
            mcqPrompt,
            { 
                role: 'user', 
                content: `Question: ${question}\nOptions:\n${options.map((opt, i) => `${String.fromCharCode(65+i)}) ${opt}`).join('\n')}${userAnswer ? `\nUser's Answer: ${userAnswer}` : ''}` 
            }
        ];

        const completion = await groq.chat.completions.create({
            messages: [
                { 
                    role: 'system', 
                    content: `You are an expert Educational AI solving MCQs.
               Rules:
               1. Read the entire question and ALL options carefully.
               2. Identify ALL correct statements/options.
               3. DO NOT give any explanation, reasoning, or extra words. Strictly output ONLY the correct option number and its text.
               
               Format strictly like this:
               (Option number) Option text
               Example: (iv) In beaker C endothermic process has occurred.` 
                },
                mcqPrompt,
                { 
                    role: 'user', 
                    content: `Question: ${question}\nOptions:\n${options.map((opt, i) => `${String.fromCharCode(65+i)}) ${opt}`).join('\n')}${userAnswer ? `\nUser's Answer: ${userAnswer}` : ''}` 
                }
            ],
            model: 'llama-3.1-8b-instant',
            max_tokens: 50, // 🚀 Tokens wapas 50 kar diye hain, ab API credit ekdum na ke barabar katega!
            temperature: 0.1 // Accuracy badhane ke liye temperature aur kam kar diya
        });

        const analysis = completion.choices[0].message.content;
        const duration = Date.now() - startTime;
        
        console.log("✅ MCQ ANALYSIS SUCCESS");
        console.log("Duration:", duration + "ms");
        console.log("=== MCQ ANALYSIS COMPLETED ===\n");
        
        res.json({ 
            analysis,
            questionType: 'MCQ',
            processingTime: duration
        });
        
    } catch (error) {
        const duration = Date.now() - startTime;
        console.error("❌ MCQ ANALYSIS FAILED");
        console.error("Duration:", duration + "ms");
        console.error("Error:", error.message);
        console.error("=== MCQ ANALYSIS FAILED ===\n");
        
        res.status(500).json({ 
            error: "Failed to analyze MCQ", 
            details: error.message 
        });
    }
});

app.post('/api/chat', async (req, res) => {
    const startTime = Date.now();
    
    try {
        console.log("=== API CALL STARTED ===");
        const { messages } = req.body;
        
        if (!messages || !Array.isArray(messages)) {
            console.error("Invalid messages format:", req.body);
            return res.status(400).json({ error: "Invalid messages format" });
        }
        
        console.log("Messages count:", messages.length);

        // Extract question details for deep thinking
        const lastMessage = messages[messages.length - 1];
        const questionDetails = extractMCQDetails(lastMessage.content);

        // Validate and clean messages
        const cleanMessages = messages.map(msg => {
            let safeRole = msg.role;
            if (safeRole === 'ai') safeRole = 'assistant'; // Magic Fix
            return { role: safeRole, content: msg.content };
        }).filter(msg => msg.role && msg.content);

        console.log("Cleaned messages:", cleanMessages);

        const isFollowUp = messages.length > 1;
        
        // ✨ PROMPT LOGIC
        const systemPrompt = isFollowUp 
            ? `You are a helpful AI teaching assistant. Answer the user's follow-up questions clearly, concisely, and naturally based on the previous context.` 
            : `You are an expert Educational AI solving MCQs.
               Rules:
               1. Identify the correct option.
               2. DO NOT change the format of the option label. If the question uses "a)", "1)", "(A)", etc., you MUST use the exact same label.
               3. DO NOT give any explanation.
               
               Format strictly like this:
               [Exact Option Label from Question] [Option text]
               Example: a) Testing individual components in isolation`;
        // ✨ DYNAMIC TOKEN LOGIC (Pehle ke liye 50, Follow-up ke liye 300)
        const tokenLimit = isFollowUp ? 350 : 50;

        const completion = await groq.chat.completions.create({
            messages: [
                { role: 'system', content: systemPrompt },
                ...cleanMessages
            ],
            model: 'llama-3.1-8b-instant',
            max_tokens: tokenLimit, 
            temperature: 0.1 
        });

        const answer = completion.choices[0].message.content;
        const duration = Date.now() - startTime;
        
        console.log("✅ API CALL SUCCESS");
        console.log("Tokens used for this call limit:", tokenLimit);
        console.log("=== API CALL COMPLETED ===\n");
        
        res.json({ 
            answer,
            deepThinking: {
                question: questionDetails.question,
                options: questionDetails.options,
                processingSteps: [
                    '🔍 Analyzing question pattern...',
                    '📊 Evaluating answer options...',
                    '⚡ Calculating correct answer...',
                    '✅ Finalizing response...'
                ],
                duration: duration,
                timestamp: new Date().toISOString()
            }
        });
        
    } catch (error) {
        console.error("❌ API CALL FAILED:", error.message);
        res.status(500).json({ 
            error: "Failed to fetch response from AI", 
            details: error.message 
        });
    }
});

// Helper function to extract MCQ details
function extractMCQDetails(text) {
    const mcqPattern = /^(.*?)(?:\n*[A-D]\)\s*.*?)(?:\n*[A-D]\)\s*.*?)(?:\n*[A-D]\)\s*.*?)(?:\n*[A-D]\)\s*.*)?$/i;
    const match = text.match(mcqPattern);
    
    if (match) {
        const question = match[1]?.trim();
        const options = [];
        for (let i = 2; i <= 5; i++) {
            if (match[i]) {
                const optionMatch = match[i].match(/[A-D]\)\s*(.*)/i);
                if (optionMatch) {
                    options.push(optionMatch[1].trim());
                }
            }
        }
        
        return { question, options: options.filter(opt => opt) };
    }
    
    return { question: text, options: [] };
}

// Global error handlers
process.on('uncaughtException', (error) => {
    console.error('💥 UNCAUGHT EXCEPTION (keeping server alive):', {
        message: error.message,
        stack: error.stack
    });
    // Don't exit, keep server running
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('💥 UNHANDLED REJECTION (keeping server alive):', {
        reason: reason,
        promise: promise
    });
    // Don't exit, keep server running
});

const PORT = process.env.PORT || 3000;
const server = app.listen(PORT, () => {
    console.log(`🚀 Backend is running fast on http://localhost:${PORT}`);
    console.log(`📊 Health check: http://localhost:${PORT}/health`);
    console.log(`🔧 Debug mode enabled - watching for crashes...\n`);
});

// Handle server errors
server.on('error', (error) => {
    if (error.code === 'EADDRINUSE') {
        console.error(`❌ Port ${PORT} is already in use`);
    } else {
        console.error('❌ Server error:', error);
    }
});
