@echo off
title AI Stealth Backend
color 0A

echo =======================================
echo    🚀 Checking dependencies...
echo =======================================

:: Check if node_modules folder exists
IF NOT EXIST "node_modules\" (
    echo [INFO] node_modules not found. Installing packages...
    echo.
    npm install
    echo.
    echo [SUCCESS] Packages installed successfully!
) ELSE (
    echo [INFO] node_modules found. Skipping installation.
)

echo.
echo =======================================
echo    🔥 AI Backend Server Start...
echo =======================================
node server.js
pause